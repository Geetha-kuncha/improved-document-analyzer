import json
import os
import re
from datetime import datetime
from typing import List, Dict, Any, Tuple, Set
import PyPDF2
import argparse
from collections import Counter, defaultdict
import math

class EnhancedAdaptiveDocumentAnalyzer:
    def __init__(self):
        # Enhanced structural analysis weights
        self.analysis_weights = {
            'content_complexity': 0.35,     # Increased weight for structural richness
            'information_density': 0.30,    # Increased weight for specific data
            'document_centrality': 0.15,    # Reduced weight for position
            'structural_uniqueness': 0.20,  # Increased weight for unique patterns
        }
        
        # Enhanced structural patterns with more specific indicators
        self.structural_patterns = {
            'travel_guide': {
                'indicators': [
                    r'\b(?:hotel|restaurant|museum|attraction|visit|tour|guide)\b',
                    r'\b(?:€|$|£)\d+(?:\.\d{2})?',
                    r'\b(?:address|phone|hours?|open|closed)\b',
                    r'\b(?:metro|bus|taxi|walking|transport)\b'
                ],
                'weight': 1.3
            },
            'technical_manual': {
                'indicators': [
                    r'\b(?:installation|setup|configuration|system|software)\b',
                    r'^\s*(?:step\s+)?\d+[\.\)]\s+',
                    r'\b(?:prerequisites|requirements|troubleshooting)\b',
                    r'\b(?:port|host|database|server|client)\b'
                ],
                'weight': 1.4
            },
            'financial_report': {
                'indicators': [
                    r'\b(?:revenue|profit|loss|financial|quarterly|annual)\b',
                    r'\b\d+(?:\.\d+)?%',
                    r'\b(?:million|billion|€|$|£)\s*\d+',
                    r'\b(?:assets|liabilities|equity|balance)\b'
                ],
                'weight': 1.2
            },
            'reference_material': {
                'indicators': [
                    r'^\s*[•\-\*]\s+[A-Z]',
                    r'^[A-Z][^:\n]{10,40}:\s*[^:\n]{20,}',
                    r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+){2,}\b',
                    r'\b(?:contact|information|details|specifications)\b'
                ],
                'weight': 1.1
            }
        }
        
        # Enhanced persona detection patterns
        self.persona_patterns = {
            'travel_planner': {
                'structural_indicators': ['prices', 'locations', 'time_references', 'contact_info'],
                'content_keywords': ['travel', 'trip', 'visit', 'destination', 'hotel', 'restaurant', 'attraction', 'guide', 'tourism'],
                'min_threshold': 0.3,
                'description': 'Someone planning travel experiences and itineraries'
            },
            'business_analyst': {
                'structural_indicators': ['measurements', 'key_value_pairs', 'proper_nouns'],
                'content_keywords': ['analysis', 'report', 'data', 'metrics', 'performance', 'revenue', 'profit', 'business'],
                'min_threshold': 0.25,
                'description': 'Someone analyzing business data and creating reports'
            },
            'technical_implementer': {
                'structural_indicators': ['numbered_lists', 'sub_lists', 'key_value_pairs'],
                'content_keywords': ['installation', 'setup', 'configuration', 'system', 'software', 'technical', 'manual'],
                'min_threshold': 0.4,
                'description': 'Someone implementing technical solutions and following procedures'
            },
            'cultural_explorer': {
                'structural_indicators': ['proper_nouns', 'locations', 'time_references'],
                'content_keywords': ['culture', 'history', 'museum', 'art', 'heritage', 'tradition', 'historical'],
                'min_threshold': 0.2,
                'description': 'Someone exploring cultural and historical experiences'
            }
        }
        
        # Enhanced job detection patterns
        self.job_patterns = {
            'plan_travel_itinerary': {
                'structural_indicators': ['time_references', 'locations', 'prices'],
                'content_keywords': ['plan', 'itinerary', 'schedule', 'days', 'visit', 'travel'],
                'min_threshold': 0.3,
                'description': 'Planning a comprehensive travel itinerary with activities and logistics'
            },
            'find_accommodations_dining': {
                'structural_indicators': ['contact_info', 'prices', 'locations'],
                'content_keywords': ['hotel', 'restaurant', 'accommodation', 'dining', 'stay', 'eat'],
                'min_threshold': 0.25,
                'description': 'Finding suitable accommodations and dining options'
            },
            'discover_cultural_activities': {
                'structural_indicators': ['proper_nouns', 'time_references', 'locations'],
                'content_keywords': ['museum', 'culture', 'art', 'history', 'festival', 'event'],
                'min_threshold': 0.2,
                'description': 'Discovering cultural activities and historical experiences'
            },
            'follow_procedures': {
                'structural_indicators': ['numbered_lists', 'sub_lists', 'bullet_points'],
                'content_keywords': ['step', 'procedure', 'installation', 'setup', 'configuration'],
                'min_threshold': 0.4,
                'description': 'Following step-by-step procedures and implementation guides'
            }
        }
    
    def extract_structural_personas_enhanced(self, all_blocks: List[Dict[str, Any]], collection_profile: Dict[str, Any]) -> List[Dict[str, str]]:
        """Enhanced persona extraction using combined structural and content analysis"""
        personas = []
        
        # Aggregate all content for analysis
        all_content = ' '.join([block['content'].lower() for block in all_blocks])
        all_titles = ' '.join([block['title'].lower() for block in all_blocks])
        combined_text = all_content + ' ' + all_titles
        
        # Aggregate structural elements
        total_elements = defaultdict(int)
        total_blocks = len(all_blocks)
        
        for block in all_blocks:
            for element, count in block['structural_elements'].items():
                total_elements[element] += count
        
        # Calculate persona scores
        persona_scores = {}
        
        for persona_type, pattern_info in self.persona_patterns.items():
            score = 0.0
            
            # Structural score (60% weight)
            structural_score = 0.0
            for indicator in pattern_info['structural_indicators']:
                if indicator in total_elements:
                    # Normalize by number of blocks
                    element_density = total_elements[indicator] / total_blocks
                    structural_score += element_density
            
            structural_score = min(structural_score / len(pattern_info['structural_indicators']), 1.0)
            
            # Content score (40% weight)
            content_score = 0.0
            word_count = len(combined_text.split())
            
            if word_count > 0:
                for keyword in pattern_info['content_keywords']:
                    occurrences = combined_text.count(keyword)
                    content_score += occurrences / word_count
            
            content_score = min(content_score * 100, 1.0)  # Scale up content score
            
            # Combined score
            final_score = (structural_score * 0.6) + (content_score * 0.4)
            
            # Apply collection profile bonus
            if collection_profile.get('collection_focus') == 'data_rich' and persona_type == 'business_analyst':
                final_score *= 1.3
            elif collection_profile.get('collection_focus') == 'structured' and persona_type == 'technical_implementer':
                final_score *= 1.3
            elif collection_profile.get('dominant_document_type') == 'reference' and persona_type in ['travel_planner', 'cultural_explorer']:
                final_score *= 1.2
            
            persona_scores[persona_type] = final_score
        
        # Create personas from scores above threshold
        for persona_type, score in sorted(persona_scores.items(), key=lambda x: x[1], reverse=True):
            threshold = self.persona_patterns[persona_type]['min_threshold']
            if score >= threshold:
                confidence = min(score / threshold, 1.0)
                personas.append({
                    'type': persona_type,
                    'description': self.persona_patterns[persona_type]['description'],
                    'confidence': confidence
                })
        
        return personas[:3]  # Return top 3 personas
    
    def extract_structural_jobs_enhanced(self, all_blocks: List[Dict[str, Any]], collection_profile: Dict[str, Any]) -> List[Dict[str, str]]:
        """Enhanced job extraction using combined structural and content analysis"""
        jobs = []
        
        # Aggregate all content for analysis
        all_content = ' '.join([block['content'].lower() for block in all_blocks])
        all_titles = ' '.join([block['title'].lower() for block in all_blocks])
        combined_text = all_content + ' ' + all_titles
        
        # Aggregate structural elements
        total_elements = defaultdict(int)
        total_blocks = len(all_blocks)
        
        for block in all_blocks:
            for element, count in block['structural_elements'].items():
                total_elements[element] += count
        
        # Calculate job scores
        job_scores = {}
        
        for job_type, pattern_info in self.job_patterns.items():
            score = 0.0
            
            # Structural score (70% weight for jobs)
            structural_score = 0.0
            for indicator in pattern_info['structural_indicators']:
                if indicator in total_elements:
                    element_density = total_elements[indicator] / total_blocks
                    structural_score += element_density
            
            structural_score = min(structural_score / len(pattern_info['structural_indicators']), 1.0)
            
            # Content score (30% weight)
            content_score = 0.0
            word_count = len(combined_text.split())
            
            if word_count > 0:
                for keyword in pattern_info['content_keywords']:
                    occurrences = combined_text.count(keyword)
                    content_score += occurrences / word_count
            
            content_score = min(content_score * 100, 1.0)
            
            # Combined score
            final_score = (structural_score * 0.7) + (content_score * 0.3)
            
            # Apply collection profile bonus
            if collection_profile.get('collection_focus') == 'structured' and job_type == 'follow_procedures':
                final_score *= 1.4
            elif collection_profile.get('information_richness', 0) > 0.5 and job_type in ['plan_travel_itinerary', 'find_accommodations_dining']:
                final_score *= 1.2
            
            job_scores[job_type] = final_score
        
        # Create jobs from scores above threshold
        for job_type, score in sorted(job_scores.items(), key=lambda x: x[1], reverse=True):
            threshold = self.job_patterns[job_type]['min_threshold']
            if score >= threshold:
                confidence = min(score / threshold, 1.0)
                jobs.append({
                    'type': job_type,
                    'description': self.job_patterns[job_type]['description'],
                    'confidence': confidence
                })
        
        return jobs[:3]  # Return top 3 jobs
    
    def classify_document_type_enhanced(self, full_text: str) -> str:
        """Enhanced document type classification"""
        type_scores = {}
        word_count = len(full_text.split())
        
        if word_count == 0:
            return 'general'
        
        for doc_type, pattern_info in self.structural_patterns.items():
            score = 0
            for pattern in pattern_info['indicators']:
                matches = len(re.findall(pattern, full_text, re.MULTILINE | re.IGNORECASE))
                score += matches * pattern_info['weight']
            
            # Normalize by document length
            type_scores[doc_type] = score / word_count * 1000
        
        if not any(type_scores.values()):
            return 'reference_material'  # Default to reference instead of general
        
        return max(type_scores.items(), key=lambda x: x[1])[0]
    
    def analyze_structural_elements_enhanced(self, content: str) -> Dict[str, int]:
        """Enhanced structural element analysis with better pattern recognition"""
        elements = {
            # List structures (enhanced patterns)
            'bullet_points': len(re.findall(r'^\s*[•\-\*\+]\s+\w', content, re.MULTILINE)),
            'numbered_lists': len(re.findall(r'^\s*\d+[\.\)]\s+\w', content, re.MULTILINE)),
            'lettered_lists': len(re.findall(r'^\s*[a-z]\)\s+\w', content, re.MULTILINE)),
            'sub_lists': len(re.findall(r'^\s*\d+\.\d+[\.\)]\s+\w', content, re.MULTILINE)),
            
            # Information structures (enhanced patterns)
            'key_value_pairs': len(re.findall(r'^[^:\n]{3,40}:\s*[^:\n]{10,}', content, re.MULTILINE)),
            'measurements': len(re.findall(r'\b\d+(?:\.\d+)?\s*(?:km|miles|hours?|days?|minutes?|euros?|€|$|£|%|meters?|feet|kg|lbs)\b', content, re.IGNORECASE)),
            'time_references': len(re.findall(r'\b(?:\d{1,2}:\d{2}(?:\s*[ap]m)?|\d{1,2}[ap]m|morning|afternoon|evening|night|monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|march|april|may|june|july|august|september|october|november|december)\b', content, re.IGNORECASE)),
            'locations': len(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:Street|St|Avenue|Ave|Road|Rd|Square|Place|Center|Centre|Museum|Hotel|Restaurant))\b', content)),
            'proper_nouns': len(re.findall(r'\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})*\b', content)),
            'contact_info': len(re.findall(r'\b(?:www\.|http|@[\w.-]+|\+?\d{1,3}[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,4})\b', content)),
            'prices': len(re.findall(r'\b(?:€|$|£)\s*\d+(?:\.\d{2})?|\b\d+(?:\.\d{2})?\s*(?:euros?|dollars?|pounds?)\b', content, re.IGNORECASE)),
            
            # Structural formatting (enhanced patterns)
            'indented_lines': len(re.findall(r'^\s{4,}[^\s]', content, re.MULTILINE)),
            'caps_headers': len(re.findall(r'^[A-Z][A-Z\s]{8,}$', content, re.MULTILINE)),
            'formatted_sections': len(re.findall(r'^[A-Z][^:\n]{10,60}:\s*$', content, re.MULTILINE)),
            
            # Content density indicators (enhanced patterns)
            'parenthetical_info': len(re.findall(r'$$[^)]{10,80}$$', content)),
            'quoted_content': len(re.findall(r'"[^"]{15,150}"', content)),
            'emphasized_text': len(re.findall(r'\b[A-Z]{3,}\b', content))
        }
        
        return elements
    
    def process_documents_enhanced(self, pdf_paths: List[str], input_persona: str = "", input_job: str = "") -> Dict[str, Any]:
        """Enhanced processing with better persona and job detection"""
        start_time = datetime.now()
        
        print("Starting enhanced adaptive document analysis...")
        
        # Process documents with enhanced analysis
        collection_data = {
            'documents': [],
            'collection_profile': {},
            'structural_patterns': {},
            'content_themes': {},
            'extracted_personas': [],
            'extracted_jobs': []
        }
        
        all_content_blocks = []
        document_types = []
        
        # Process each document with enhanced methods
        for pdf_path in pdf_paths:
            doc_data = self.process_single_document_enhanced(pdf_path)
            collection_data['documents'].append(doc_data)
            all_content_blocks.extend(doc_data['content_blocks'])
            document_types.append(doc_data['document_type'])
        
        print(f"Processed {len(pdf_paths)} documents with {len(all_content_blocks)} content blocks")
        
        # Enhanced collection analysis
        collection_data['collection_profile'] = self.analyze_collection_profile(document_types, all_content_blocks)
        collection_data['structural_patterns'] = self.extract_structural_patterns(all_content_blocks)
        collection_data['content_themes'] = self.extract_content_themes(all_content_blocks)
        
        # Enhanced persona and job extraction
        collection_data['extracted_personas'] = self.extract_structural_personas_enhanced(all_content_blocks, collection_data['collection_profile'])
        collection_data['extracted_jobs'] = self.extract_structural_jobs_enhanced(all_content_blocks, collection_data['collection_profile'])
        
        print(f"Discovered {len(collection_data['extracted_personas'])} personas and {len(collection_data['extracted_jobs'])} jobs")
        
        # Calculate relevance scores and prepare output
        for block in all_content_blocks:
            relevance_score = self.calculate_adaptive_relevance(block, collection_data)
            block['relevance_score'] = relevance_score
        
        all_content_blocks.sort(key=lambda x: x['relevance_score'], reverse=True)
        final_blocks = self.ensure_document_diversity(all_content_blocks)
        
        # Prepare enhanced output
        output = {
            "metadata": {
                "input_documents": [doc['filename'] for doc in collection_data['documents']],
                "original_persona": input_persona,
                "original_job": input_job,
                "processing_timestamp": start_time.isoformat(),
                "analysis_method": "enhanced_adaptive_structural_analysis",
                "collection_profile": collection_data['collection_profile'],
                "total_blocks_analyzed": len(all_content_blocks)
            },
            "discovered_personas": collection_data['extracted_personas'],
            "discovered_jobs": collection_data['extracted_jobs'],
            "structural_patterns": collection_data['structural_patterns'],
            "content_themes": collection_data['content_themes'],
            "extracted_sections": [],
            "subsection_analysis": []
        }
        
        # Add top sections
        for rank, block in enumerate(final_blocks[:10], 1):
            output["extracted_sections"].append({
                "document": block["document"],
                "section_title": block["title"],
                "importance_rank": rank,
                "page_number": block["page_number"],
                "relevance_score": round(block["relevance_score"], 3),
                "complexity_score": round(block["complexity_score"], 3),
                "density_score": round(block["density_score"], 3),
                "uniqueness_score": round(block["uniqueness_score"], 3),
                "content_type": block["content_type"],
                "word_count": block["word_count"],
                "structural_elements": block["structural_elements"]
            })
            
            # Add subsections for top 5
            if rank <= 5:
                try:
                    refined_text = block['content'][:500] + "..." if len(block['content']) > 500 else block['content']
                    output["subsection_analysis"].append({
                        "document": block["document"],
                        "refined_text": refined_text,
                        "page_number": block["page_number"],
                        "parent_section": block["title"]
                    })
                except Exception as e:
                    print(f"Error adding subsection: {e}")
                    continue
        
        return output
    
    def process_single_document_enhanced(self, pdf_path: str) -> Dict[str, Any]:
        """Enhanced single document processing"""
        document_name = os.path.basename(pdf_path)
        doc_data = {
            'filename': document_name,
            'content_blocks': [],
            'document_type': 'unknown',
            'structural_profile': {},
            'page_count': 0
        }
        
        try:
            with open(pdf_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                doc_data['page_count'] = len(pdf_reader.pages)
                
                all_text = ""
                for page_num, page in enumerate(pdf_reader.pages, 1):
                    page_text = page.extract_text()
                    all_text += page_text
                    
                    # Extract content blocks with enhanced analysis
                    page_blocks = self.extract_content_blocks_enhanced(page_text, page_num, document_name)
                    doc_data['content_blocks'].extend(page_blocks)
                
                # Enhanced document classification
                doc_data['document_type'] = self.classify_document_type_enhanced(all_text)
                doc_data['structural_profile'] = self.analyze_document_structure(all_text)
                
        except Exception as e:
            print(f"Error processing {pdf_path}: {e}")
        
        return doc_data
    
    def extract_content_blocks_enhanced(self, page_text: str, page_num: int, document_name: str) -> List[Dict[str, Any]]:
        """Enhanced content block extraction"""
        lines = [line.strip() for line in page_text.split('\n') if line.strip()]
        content_blocks = []
        
        if len(lines) < 5:
            return content_blocks
        
        # Use enhanced sliding window
        window_size = 15  # Larger window for better context
        step_size = 8     # Larger step for less overlap
        
        for i in range(0, len(lines) - window_size + 1, step_size):
            window_lines = lines[i:i + window_size]
            
            # Enhanced block analysis
            block_analysis = self.analyze_content_window_enhanced(window_lines, i, page_num, document_name)
            
            # Enhanced threshold check
            if self.meets_enhanced_threshold(block_analysis):
                content_blocks.append(block_analysis)
        
        # Enhanced merging and filtering
        merged_blocks = self.merge_and_filter_blocks_enhanced(content_blocks)
        
        return merged_blocks
    
    def analyze_content_window_enhanced(self, window_lines: List[str], start_idx: int, page_num: int, document_name: str) -> Dict[str, Any]:
        """Enhanced content window analysis"""
        content_text = '\n'.join(window_lines)
        
        analysis = {
            'content': content_text,
            'lines': window_lines,
            'page_number': page_num,
            'document': document_name,
            'start_index': start_idx,
            'word_count': len(content_text.split()),
            'structural_elements': {},
            'content_type': 'general',
            'complexity_score': 0.0,
            'density_score': 0.0,
            'uniqueness_score': 0.0,
            'title': ''
        }
        
        # Enhanced structural analysis
        analysis['structural_elements'] = self.analyze_structural_elements_enhanced(content_text)
        
        # Enhanced content type classification
        analysis['content_type'] = self.classify_content_type_enhanced(window_lines, content_text)
        
        # Enhanced scoring
        analysis['complexity_score'] = self.calculate_structural_complexity_enhanced(analysis)
        analysis['density_score'] = self.calculate_information_density_enhanced(content_text)
        analysis['uniqueness_score'] = self.calculate_structural_uniqueness_enhanced(analysis)
        
        # Enhanced title generation
        analysis['title'] = self.generate_structural_title_enhanced(window_lines, analysis['content_type'])
        
        return analysis
    
    def classify_content_type_enhanced(self, lines: List[str], content_text: str) -> str:
        """Enhanced content type classification"""
        # Check against enhanced document type patterns
        type_scores = {}
        
        for doc_type, pattern_info in self.structural_patterns.items():
            score = 0
            for pattern in pattern_info['indicators']:
                matches = len(re.findall(pattern, content_text, re.MULTILINE | re.IGNORECASE))
                score += matches * pattern_info['weight']
            type_scores[doc_type] = score
        
        if not any(type_scores.values()):
            return 'reference_material'
        
        best_type = max(type_scores.items(), key=lambda x: x[1])[0]
        
        # Map document types to content types
        type_mapping = {
            'travel_guide': 'reference',
            'technical_manual': 'procedural',
            'financial_report': 'informational',
            'reference_material': 'reference'
        }
        
        return type_mapping.get(best_type, 'reference')
    
    def calculate_structural_complexity_enhanced(self, analysis: Dict[str, Any]) -> float:
        """Enhanced complexity calculation"""
        elements = analysis['structural_elements']
        
        # Weight different elements by importance
        element_weights = {
            'bullet_points': 1.0,
            'numbered_lists': 1.2,
            'key_value_pairs': 1.1,
            'measurements': 1.3,
            'proper_nouns': 0.8,
            'contact_info': 1.4,
            'prices': 1.3,
            'time_references': 1.2
        }
        
        weighted_score = 0.0
        total_weight = 0.0
        
        for element, count in elements.items():
            if count > 0:
                weight = element_weights.get(element, 1.0)
                weighted_score += count * weight
                total_weight += weight
        
        if analysis['word_count'] == 0 or total_weight == 0:
            return 0.0
        
        # Normalize by word count and total weight
        complexity = (weighted_score / analysis['word_count']) * (total_weight / len(elements))
        
        return min(complexity * 2, 1.0)  # Scale and cap at 1.0
    
    def calculate_information_density_enhanced(self, content: str) -> float:
        """Enhanced information density calculation"""
        if not content.strip():
            return 0.0
        
        words = content.split()
        word_count = len(words)
        
        if word_count == 0:
            return 0.0
        
        # Enhanced information indicators with better weights
        info_score = 0.0
        
        # High-value information patterns
        info_score += len(re.findall(r'\b\d+(?:\.\d+)?\s*(?:€|$|£|%|km|miles|hours?)\b', content)) * 3.0
        info_score += len(re.findall(r'\b\d{1,2}:\d{2}(?:\s*[ap]m)?\b', content)) * 2.5
        info_score += len(re.findall(r'\b(?:www\.|http|@[\w.-]+)\b', content)) * 2.0
        info_score += len(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*(?:\s+(?:Street|Hotel|Restaurant|Museum))\b', content)) * 1.5
        info_score += len(re.findall(r'^\s*[•\-\*]\s+[A-Z]', content, re.MULTILINE)) * 1.0
        
        return min(info_score / word_count * 10, 2.0)
    
    def calculate_structural_uniqueness_enhanced(self, analysis: Dict[str, Any]) -> float:
        """Enhanced uniqueness calculation"""
        elements = analysis['structural_elements']
        
        # Rare element combinations get higher scores
        uniqueness_score = 0.0
        
        # High-value combinations
        if elements['contact_info'] > 0 and elements['prices'] > 0:
            uniqueness_score += 0.4
        
        if elements['measurements'] > 1 and elements['time_references'] > 0:
            uniqueness_score += 0.3
        
        if elements['numbered_lists'] > 0 and elements['key_value_pairs'] > 2:
            uniqueness_score += 0.3
        
        # Individual rare elements
        rare_elements = ['contact_info', 'prices', 'sub_lists', 'formatted_sections']
        for element in rare_elements:
            if elements.get(element, 0) > 0:
                uniqueness_score += 0.1
        
        return min(uniqueness_score, 1.0)
    
    def generate_structural_title_enhanced(self, lines: List[str], content_type: str) -> str:
        """Enhanced title generation"""
        # Look for the most informative line
        best_title = ""
        best_score = 0
        
        for line in lines[:8]:  # Check more lines
            line_clean = line.strip()
            
            if len(line_clean) < 10 or len(line_clean) > 100:
                continue
            
            score = 0
            
            # Proper nouns indicate specific content
            proper_nouns = len(re.findall(r'\b[A-Z][a-z]{2,}\b', line_clean))
            score += proper_nouns * 2
            
            # Numbers and measurements
            numbers = len(re.findall(r'\b\d+(?:\.\d+)?\b', line_clean))
            score += numbers * 1.5
            
            # Avoid list markers
            if re.match(r'^\s*[•\-\*\+\d+\.\)]\s+', line_clean):
                score -= 2
            
            # Prefer lines with colons (key-value structure)
            if ':' in line_clean and len(line_clean.split(':')) == 2:
                score += 3
            
            # Prefer capitalized words
            caps_words = len(re.findall(r'\b[A-Z][a-z]+\b', line_clean))
            score += caps_words * 0.5
            
            if score > best_score:
                best_score = score
                best_title = line_clean
        
        if best_title:
            # Clean up the title
            best_title = re.sub(r'^\d+[\.\)]\s*', '', best_title)
            best_title = re.sub(r'^[•\-\*\+]\s*', '', best_title)
            
            if len(best_title) > 80:
                best_title = best_title[:77] + "..."
            
            return best_title
        
        # Fallback titles based on content type
        fallback_titles = {
            'procedural': 'Step-by-Step Instructions',
            'informational': 'Information Summary',
            'reference': 'Reference Information',
            'general': 'Content Section'
        }
        
        return fallback_titles.get(content_type, 'Content Section')
    
    def meets_enhanced_threshold(self, analysis: Dict[str, Any]) -> bool:
        """Enhanced threshold checking"""
        # More lenient word count for better coverage
        if analysis['word_count'] < 40:
            return False
        
        # Lower complexity threshold but require some structure
        if analysis['complexity_score'] < 0.15:
            return False
        
        # Require minimum information density
        if analysis['density_score'] < 0.2:
            return False
        
        # Must have at least some structural elements
        total_elements = sum(analysis['structural_elements'].values())
        if total_elements < 1:
            return False
        
        return True
    
    def merge_and_filter_blocks_enhanced(self, content_blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Enhanced block merging and filtering"""
        if not content_blocks:
            return []
        
        # Sort by start index
        sorted_blocks = sorted(content_blocks, key=lambda x: x['start_index'])
        merged = []
        
        current_block = sorted_blocks[0]
        
        for next_block in sorted_blocks[1:]:
            # Check for overlap
            current_end = current_block['start_index'] + len(current_block['lines'])
            overlap = max(0, current_end - next_block['start_index'])
            
            if overlap > len(current_block['lines']) * 0.3:  # 30% overlap threshold
                # Keep the block with higher combined score
                current_combined = current_block['complexity_score'] + current_block['density_score']
                next_combined = next_block['complexity_score'] + next_block['density_score']
                
                if next_combined > current_combined:
                    current_block = next_block
            else:
                merged.append(current_block)
                current_block = next_block
        
        merged.append(current_block)
        
        # Enhanced filtering - keep more blocks but ensure quality
        quality_blocks = [block for block in merged if 
                         (block['complexity_score'] + block['density_score']) > 0.4]
        
        # Sort by combined score
        quality_blocks.sort(key=lambda x: (x['complexity_score'] + x['density_score']), reverse=True)
        
        return quality_blocks[:25]  # Return more blocks per document
    
    def calculate_adaptive_relevance(self, block: Dict[str, Any], collection_data: Dict[str, Any]) -> float:
        """Calculate relevance with enhanced weighting"""
        # Enhanced scoring with better balance
        complexity_weight = 0.35
        density_weight = 0.35
        uniqueness_weight = 0.30
        
        final_score = (
            block['complexity_score'] * complexity_weight +
            block['density_score'] * density_weight +
            block['uniqueness_score'] * uniqueness_weight
        )
        
        return min(final_score, 1.0)
    
    def ensure_document_diversity(self, blocks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Ensure diverse representation with enhanced logic"""
        diverse_blocks = []
        doc_counts = {}
        max_per_doc = 4  # Allow more blocks per document
        
        for block in blocks:
            doc_name = block.get('document', '')
            current_count = doc_counts.get(doc_name, 0)
            
            if current_count < max_per_doc:
                diverse_blocks.append(block)
                doc_counts[doc_name] = current_count + 1
            
            if len(diverse_blocks) >= 15:  # Return more total blocks
                break
        
        return diverse_blocks

# Usage example and main function would go here...
def main():
    parser = argparse.ArgumentParser(description='Enhanced Adaptive Document Intelligence System')
    parser.add_argument('--input_dir', required=True, help='Directory containing PDF files')
    parser.add_argument('--persona', default='', help='Optional persona description')
    parser.add_argument('--job', default='', help='Optional job description')
    parser.add_argument('--output', default='enhanced_output.json', help='Output JSON file')
    
    args = parser.parse_args()
    
    # Find PDF files
    pdf_files = []
    for file in os.listdir(args.input_dir):
        if file.lower().endswith('.pdf'):
            pdf_files.append(os.path.join(args.input_dir, file))
    
    if not pdf_files:
        print("No PDF files found in input directory")
        return
    
    print(f"Found {len(pdf_files)} PDF files")
    print("Using enhanced adaptive structural analysis...")
    
    # Initialize enhanced system
    analyzer = EnhancedAdaptiveDocumentAnalyzer()
    
    # Process documents with enhanced methods
    result = analyzer.process_documents_enhanced(pdf_files, args.persona, args.job)
    
    # Save output
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False)
    
    print(f"\nProcessing complete. Output saved to {args.output}")
    print(f"Found {len(result['extracted_sections'])} relevant sections")
    print(f"Discovered {len(result['discovered_personas'])} personas and {len(result['discovered_jobs'])} jobs")
    
    # Print results
    print("\n=== DISCOVERED PERSONAS ===")
    for persona in result['discovered_personas']:
        print(f"- {persona['type']}: {persona['description']} (confidence: {persona['confidence']:.2f})")
    
    print("\n=== DISCOVERED JOBS ===")
    for job in result['discovered_jobs']:
        print(f"- {job['type']}: {job['description']} (confidence: {job['confidence']:.2f})")

if __name__ == "__main__":
    main()
